/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './angelbot.ui/index.html',
    './angelbot.ui/src/**/*.{ts,tsx,js,jsx}',
  ],
  theme: { extend: {} },
  plugins: [],
}

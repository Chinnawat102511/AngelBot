export const cls = (...a: (string|false|undefined)[]) => a.filter(Boolean).join(' ')

// protection rule check

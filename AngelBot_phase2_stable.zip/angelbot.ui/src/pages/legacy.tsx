// src/pages/legacy.tsx
export default function LegacyConsole() {
  return (
    <div style={{ padding: 16 }}>
      <h2>Legacy Console</h2>
      <p>หน้านี้เป็นที่ย้าย UI เก่ามาชั่วคราว</p>
    </div>
  );
}

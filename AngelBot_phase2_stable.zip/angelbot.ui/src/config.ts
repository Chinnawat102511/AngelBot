export const API_BASE = (import.meta as any).env.VITE_API_BASE?.replace(/\/$/, "") || "";
